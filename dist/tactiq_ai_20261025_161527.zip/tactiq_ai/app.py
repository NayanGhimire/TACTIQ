"""TACTIQ AI - Main Gradio Dashboard Application.

Interactive visual-first football intelligence platform with 10 sections:
1. Live Match
2. Tactical DNA
3. Build-up Analysis
4. Attacking Patterns
5. Defensive Analysis
6. Transitions and Match Control
7. Player Focus
8. Match Timeline
9. AI Tactical Report
10. Viewer Preferences
"""

import json
import os
import logging
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

# Support both package import and direct script execution
if __package__ is None or __package__ == "":
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gradio as gr
import plotly.graph_objects as go
import numpy as np

try:
    # Package-style relative imports (when imported as part of tactiq_ai)
    from .config import (
        PROJECT_ROOT, MODEL_PATH, LABEL_MAPPING_PATH, FEATURE_CONFIG_PATH,
        LOW_CONFIDENCE_THRESHOLD, SOURCE_SYNTHETIC, APP_NAME
    )
    from .schemas import (
        ETYPES, ETYPE_TO_ID, T_MAX, MIN_EVENTS, _get_zone, _get_channel,
        TacticalEvent, rescale_coordinates_to_100x100, flip_coordinates_for_away_team,
        generate_synthetic_event,
        generate_possession_build_up_sequence, generate_direct_progression_sequence,
        generate_high_press_sequence,
    )
    from .data.synthetic_generator import (
        generate_single_match_scenario as gen_scenario,
        generate_full_synthetic_match,
        tactical_identities,
    )
    from .data.event_loader import MatchProcessor, validate_event_sequence
    from .data.validation import DataQualityReport, validate_events_bulk
    from .features.inference import InferenceAgent
    from .features.adapter import events_to_model_dict, extract_model_window, classify_sequence_window
    from .analytics.buildup import calculate_build_up_segments, build_profile_from_sequences
    from .analytics.attack import calculate_attack_patterns
    from .analytics.defence import calculate_defensive_behaviour
    from .analytics.transitions import calculate_transitions
    from .analytics.player_analysis import calculate_player_metrics_from_events, build_player_focus_profile
    from .agents.event_interpreter import EventInterpreterAgent
    from .agents.tactical_analyst import TacticalAnalystAgent
    from .agents.keras_inference_agent import KerasInferenceAgent
    from .agents.player_analyst import PlayerAnalystAgent
    from .agents.narrative_generator import NarrativeGeneratorAgent
    from .agents.evidence_validator import EvidenceValidatorAgent
    from .agents.personalization import PersonalizationAgent
    from .agents.overlay_formatter import OverlayFormatterAgent
    from .agents.orchestrator import TactiqOrchestrator, Insight
    from .visualization.pitch import (
        create_pitch_figure, add_pitch_players, add_pass_trajectories,
        add_event_markers, add_zone_highlight, create_shot_map,
        add_possession_arc
    )
    from .visualization.charts import (
        passing_network_chart, shot_map_chart, channel_distribution_chart,
        possession_timeline_chart, defensive_actions_chart, player_metrics_chart,
        model_prediction_chart
    )
    from .visualization.timeline import create_match_timeline, create_event_inspection_panel, create_insight_timeline
except ImportError:
    # Script-style absolute imports (when run directly from tactiq_ai/ directory)
    from config import (
        PROJECT_ROOT, MODEL_PATH, LABEL_MAPPING_PATH, FEATURE_CONFIG_PATH,
        LOW_CONFIDENCE_THRESHOLD, SOURCE_SYNTHETIC, APP_NAME
    )
    from schemas import (
        ETYPES, ETYPE_TO_ID, T_MAX, MIN_EVENTS, _get_zone, _get_channel,
        TacticalEvent, rescale_coordinates_to_100x100, flip_coordinates_for_away_team,
        generate_synthetic_event,
        generate_possession_build_up_sequence, generate_direct_progression_sequence,
        generate_high_press_sequence,
    )
    from data.synthetic_generator import (
        generate_single_match_scenario as gen_scenario,
        generate_full_synthetic_match,
        tactical_identities,
    )
    from data.event_loader import MatchProcessor, validate_event_sequence
    from data.validation import DataQualityReport, validate_events_bulk
    from features.inference import InferenceAgent
    from features.adapter import events_to_model_dict, extract_model_window, classify_sequence_window
    from analytics.buildup import calculate_build_up_segments, build_profile_from_sequences
    from analytics.attack import calculate_attack_patterns
    from analytics.defence import calculate_defensive_behaviour
    from analytics.transitions import calculate_transitions
    from analytics.player_analysis import calculate_player_metrics_from_events, build_player_focus_profile
    from agents.event_interpreter import EventInterpreterAgent
    from agents.tactical_analyst import TacticalAnalystAgent
    from agents.keras_inference_agent import KerasInferenceAgent
    from agents.player_analyst import PlayerAnalystAgent
    from agents.narrative_generator import NarrativeGeneratorAgent
    from agents.evidence_validator import EvidenceValidatorAgent
    from agents.personalization import PersonalizationAgent
    from agents.overlay_formatter import OverlayFormatterAgent
    from agents.orchestrator import TactiqOrchestrator, Insight
    from visualization.pitch import (
        create_pitch_figure, add_pitch_players, add_pass_trajectories,
        add_event_markers, add_zone_highlight, create_shot_map,
        add_possession_arc
    )
    from visualization.charts import (
        passing_network_chart, shot_map_chart, channel_distribution_chart,
        possession_timeline_chart, defensive_actions_chart, player_metrics_chart,
        model_prediction_chart
    )
    from visualization.timeline import create_match_timeline, create_event_inspection_panel, create_insight_timeline

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------------------------
# Global state
# ----------------------------------------------------------------------------------------

match_processor: Optional[MatchProcessor] = None
orchestrator: Optional[TactiqOrchestrator] = None
narrative_generator: Optional[NarrativeGeneratorAgent] = None
personalization_agent: Optional[PersonalizationAgent] = None
current_match_events: List[Dict[str, Any]] = []
current_match_state: Dict[str, Any] = {}

# ----------------------------------------------------------------------------------------
# Model loading
# ----------------------------------------------------------------------------------------


def load_default_model() -> Optional[InferenceAgent]:
    """Load the existing Keras model via the InferenceAgent."""
    try:
        agent = InferenceAgent()
        # Verify model can predict
        test_events = [
            dict(type="pass", x_start=40, y_start=55, x_end=33, y_end=60, duration_s=1.8),
            dict(type="tackle", x_start=33, y_start=60, x_end=33, y_end=60, duration_s=0.9, completed=True),
            dict(type="carry", x_start=33, y_start=60, x_end=55, y_end=55, duration_s=2.5),
            dict(type="pass", x_start=55, y_start=55, x_end=85, y_end=50, duration_s=1.6),
        ]
        result = agent.classify_sequence(test_events)
        return agent
    except Exception as e:
        logger.error(f"Model loading error: {e}")
        return None


def init_orchestrator() -> TactiqOrchestrator:
    """Initialize the full agent orchestrator."""
    global orchestrator, narrative_generator, personalization_agent
    orchestrator = TactiqOrchestrator()
    narrative_generator = NarrativeGeneratorAgent()
    personalization_agent = PersonalizationAgent()
    return orchestrator


# ----------------------------------------------------------------------------------------
# Event generation helpers
# ----------------------------------------------------------------------------------------


def get_default_match_events() -> List[Dict[str, Any]]:
    """Generate default synthetic match events for demo."""
    global current_match_events
    # Generate a possession vs counter scenario
    scenario = generate_single_match_scenario(
        "possession_vs_counter", seed=42
    )
    current_match_events = scenario["events"]
    current_match_state.update({
        "match_id": scenario["match_id"],
        "home_team": scenario["home_team"],
        "away_team": scenario["away_team"],
        "home_score": scenario["home_score"],
        "away_score": scenario["away_score"],
        "source": SOURCE_SYNTHETIC,
    })
    return current_match_events


def export_overlays_to_json(overlays: List[Dict[str, Any]]) -> str:
    """Export overlays as downloadable JSON."""
    import tempfile
    output_path = str(PROJECT_ROOT / "sample_overlays.json")
    with open(output_path, "w") as f:
        json.dump(overlays, f, indent=2)
    return output_path


# ----------------------------------------------------------------------------------------
# Analysis callback functions (for Gradio interactivity)
# ----------------------------------------------------------------------------------------


def analyze_buildup(events: List[Dict[str, Any]], team_id: str) -> Dict[str, Any]:
    """Calculate build-up analysis for a team."""
    if not events:
        return {}
    data = calculate_build_up_segments(events, team_id)
    return {
        "defensive_third_starts": data["defensive_third_starts"],
        "third_crossings": data["third_crossings"],
        "total_passes": data["total_passes"],
        "completed_passes": data["completed_passes"],
        "completion_rate": data["completion_rate"],
        "pressure_build_up": data["pressure_build_up"],
        "turnovers_in_build_up": data["turnovers_in_build_up"],
    }


def analyze_attack(events: List[Dict[str, Any]], team_id: str) -> Dict[str, Any]:
    """Calculate attacking patterns for a team."""
    if not events:
        return {}
    data = calculate_attack_patterns(events, team_id)
    return {
        "final_third_entries": data["final_third_entries"],
        "box_entries": data["box_entries"],
        "total_shots": data["total_shots"],
        "shots_on_target": data["shots_on_target"],
        "goals": data["goals"],
        "shot_conversion": data["shot_conversion_rate"],
        "shots_by_channel": data["shots_by_channel"],
    }


def analyze_defence(events: List[Dict[str, Any]], team_id: str) -> Dict[str, Any]:
    """Calculate defensive behaviour for a team."""
    if not events:
        return {}
    data = calculate_defensive_behaviour(events, team_id)
    return {
        "total_actions": data["total_defensive_actions"],
        "pressures": data["pressures"],
        "tackles": data["tackles"],
        "tackle_success": data["tackle_success_rate"],
        "pressure_success": data["pressure_success_rate"],
        "zone_distribution": data["zone_distribution"],
    }


def analyze_transitions(events: List[Dict[str, Any]], team_id: str) -> Dict[str, Any]:
    """Calculate transition metrics for a team."""
    if not events:
        return {}
    data = calculate_transitions(events, team_id)
    return {
        "possessions": data["total_possessions"],
        "avg_duration": data["avg_possession_duration_s"],
        "counter_presses": data["counter_presses"],
        "dangerous_turnovers": data["dangerous_turnovers"],
        "avg_time_between": data["avg_time_between_events_s"],
    }


def analyze_player(player_id: str, all_events: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate player metrics."""
    if not all_events:
        return {}
    metrics = calculate_player_metrics_from_events(
        all_events, player_id,
        next((e.get("player_name", "?") for e in all_events if e.get("player_id") == player_id), "?"),
        next((e.get("team_id", "?") for e in all_events if e.get("player_id") == player_id), "?"),
        next((e.get("position", "?") for e in all_events if e.get("player_id") == player_id), "?"),
    )
    return {
        "total_passes": metrics.total_passes,
        "completed_passes": metrics.completed_passes,
        "pass_accuracy": metrics.pass_completion_rate,
        "total_carries": metrics.total_carries,
        "successful_carries": metrics.successful_carries,
        "carry_success": metrics.carry_success_rate,
        "total_shots": metrics.total_shots,
        "shots_on_target": metrics.shots_on_target,
        "goals": metrics.goals,
        "pressing": metrics.pressures_applied,
        "tackles": metrics.tackles,
        "tackles_won": metrics.tackles_won,
        "recoveries": metrics.recoveries,
        "interceptions": metrics.interceptions,
    }


def run_model_inference(events: List[Dict[str, Any]], team_id: str) -> Dict[str, Any]:
    """Run the Keras model classifier on event sequence."""
    agent = InferenceAgent()

    # Convert to model format
    model_events = events_to_model_dict(events, team_id)

    # Extract window
    window = extract_model_window(model_events)

    if not window:
        return {"predicted_class": "other_or_uncertain", "confidence": 0.0, "flags": []}

    # Classify
    result = agent.classify_sequence(window)
    return {
        "predicted_class": result["predicted_class"],
        "confidence": result["model_confidence"],
        "runner_up": result["runner_up"],
        "margin": result["margin_over_runner_up"],
        "flags": result["flags"],
        "n_events": result["n_events"],
    }


def generate_narrative(insights: List[Dict[str, Any]], viewer_type: str, language: str) -> str:
    """Generate narrative from insights."""
    if not narrative_generator:
        return "Narrative generation unavailable."
    # Just use the first finding as an example
    if insights:
        finding = insights[0]
        return narrative_generator.generate(finding, viewer_type, language)
    return ""


# ----------------------------------------------------------------------------------------
# Gradio App
# ----------------------------------------------------------------------------------------


def launch_app():
    """Launch the TACTIQ AI Gradio dashboard."""

    # Initialize
    init_orchestrator()
    model_agent = load_default_model()
    if model_agent:
        logger.info("Model loaded successfully")
    else:
        logger.warning("Model could not be loaded")

    # Generate default match events
    default_events = get_default_match_events()

    # Analyze default events
    orchestrator_result = orchestrator.run(default_events) if orchestrator else None
    default_insights = orchestrator_result.insights if orchestrator_result else []
    default_overlays = orchestrator_result.overlays if orchestrator_result else []
    export_overlays_to_json(default_overlays)

    viewer_prefs = {
        "viewer_type": "casual_fan",
        "language": "en",
        "depth": "medium",
        "interest_areas": [],
    }

    with gr.Blocks(
        title="TACTIQ AI — Football Intelligence Platform",
        theme=gr.themes.Soft(
            primary_color="#1a1a2e",
            secondary_color="#16213e",
            accent_color="#e94560",
        ),
        html="""
        <div style="text-align: center; padding: 20px;">
            <h1 style="color: white; margin-bottom: 5px;">TACTIQ AI</h1>
            <p style="color: #aaa; font-size: 14px;">Football Intelligence Platform — Phase 2</p>
            <p style="color: #666; font-size: 12px;">Synthetic data predictions | Not real-match analysis</p>
        </div>
        """,
    ) as app:

        gr.Markdown("# TACTIQ AI — Football Intelligence Platform")

        # --------------------------------------------------------------------------
        # TAB 1: Live Match
        # --------------------------------------------------------------------------
        with gr.Tab("Live Match"):
            gr.Markdown("### Live-Style Match Dashboard")
            with gr.Row():
                with gr.Column(scale=1):
                    with gr.Accordion("Match Controls", open=True):
                        home_team_inp = gr.Textbox(value="Manchester City", label="Home Team")
                        away_team_inp = gr.Textbox(value="Liverpool", label="Away Team")
                        gen_btn = gr.Button("Generate Match", size="sm")
                        reset_btn = gr.Button("Reset", size="sm")
                        pause_btn = gr.Button("Pause", size="sm")
                        resume_btn = gr.Button("Resume", size="sm")

                    with gr.Accordion("Personal Preferences", open=False):
                        viewer_type = gr.Dropdown(
                            choices=["casual_fan", "tactical_analyst", "player_focus", "custom"],
                            value="casual_fan",
                            label="Viewer Type",
                        )
                        language = gr.Dropdown(
                            choices=["en", "es", "fr"],
                            value="en",
                            label="Language",
                        )
                        depth = gr.Dropdown(
                            choices=["short", "detailed"],
                            value="medium",
                            label="Explanation Depth",
                        )

                with gr.Column(scale=2):
                    # Pitch visualization
                    pitch_fig = gr.Plot(
                        value=lambda: create_pitch_figure(title="Live Match"),
                        label="Interactive Pitch",
                    )
                    # Scoreboard
                    with gr.Accordion("Score & Clock", open=True):
                        home_score = gr.Number(value=0, label="Home", interactive=False)
                        away_score = gr.Number(value=0, label="Away", interactive=False)
                        match_clock = gr.Number(value=0, label="Clock (s)", interactive=False)
                        period = gr.Number(value=1, label="Period", interactive=False)

            # Event timeline
            with gr.Row():
                timeline_fig = gr.Plot(value=lambda: create_match_timeline(default_events),
                                       label="Match Timeline", scale=2)

            # Key events panel
            with gr.Accordion("Important Events", open=True):
                events_dropdown = gr.Dropdown(
                    choices=[e.get("event_id", "?") for e in default_events[:20]],
                    value=None,
                    label="Select Event",
                    multiselect=False,
                )
                event_inspect_fig = gr.Plot(value=lambda: create_event_inspection_panel(default_events),
                                            label="Event Inspection", scale=1)

        # --------------------------------------------------------------------------
        # TAB 2: Tactical DNA
        # --------------------------------------------------------------------------
        with gr.Tab("Tactical DNA"):
            gr.Markdown("### Team Profile — Tactical DNA")
            with gr.Row():
                with gr.Column(scale=1):
                    home_profile_fig = gr.Plot(label="Home Team Profile")
                    away_profile_fig = gr.Plot(label="Away Team Profile")
                with gr.Column(scale=1):
                    build_up_home = gr.Plot(label="Build-up Profile")
                    build_up_away = gr.Plot(label="Build-up Profile Away")

            # Profile summary
            with gr.Row():
                home_possession = gr.Number(label="Avg Possession", value=55.0, interactive=False)
                away_possession = gr.Number(label="Avg Possession", value=45.0, interactive=False)

        # --------------------------------------------------------------------------
        # TAB 3: Build-up Analysis
        # --------------------------------------------------------------------------
        with gr.Tab("Build-up Analysis"):
            gr.Markdown("### How Teams Build Up from Defence")
            with gr.Row():
                with gr.Column(scale=1):
                    passing_network_home = gr.Plot(label="Passing Network")
                    passing_network_away = gr.Plot(label="Passing Network Away")
                with gr.Column(scale=1):
                    zone_heatmap_home = gr.Plot(label="Zone Heatmap")
                    zone_heatmap_away = gr.Plot(label="Zone Heatmap Away")

            # Build-up stats
            with gr.Row():
                home_third_starts = gr.Number(label="Defensive 3rd Starts", value=0)
                away_third_starts = gr.Number(label="Defensive 3rd Starts", value=0)
                home_completion = gr.Number(label="Completion Rate", value=0.0)
                away_completion = gr.Number(label="Completion Rate", value=0.0)

        # --------------------------------------------------------------------------
        # TAB 4: Attacking Patterns
        # --------------------------------------------------------------------------
        with gr.Tab("Attacking Patterns"):
            gr.Markdown("### Attacking Patterns & Chance Creation")
            with gr.Row():
                with gr.Column(scale=1):
                    shot_map_home = gr.Plot(label="Shot Map Home")
                    shot_map_away = gr.Plot(label="Shot Map Away")
                with gr.Column(scale=1):
                    channel_dist_home = gr.Plot(label="Channel Distribution Home")
                    channel_dist_away = gr.Plot(label="Channel Distribution Away")

            # Attack stats
            with gr.Row():
                home_final_third = gr.Number(label="Final-Third Entries", value=0)
                away_final_third = gr.Number(label="Final-Third Entries", value=0)
                home_shots = gr.Number(label="Total Shots", value=0)
                away_shots = gr.Number(label="Total Shots", value=0)
                home_goals = gr.Number(label="Goals", value=0)
                away_goals = gr.Number(label="Goals", value=0)

        # --------------------------------------------------------------------------
        # TAB 5: Defensive Analysis
        # --------------------------------------------------------------------------
        with gr.Tab("Defensive Analysis"):
            gr.Markdown("### Defensive Behaviour")
            with gr.Row():
                with gr.Column(scale=1):
                    defensive_home = gr.Plot(label="Defensive Profile Home")
                    defensive_away = gr.Plot(label="Defensive Profile Away")
                with gr.Column(scale=1):
                    zone_def_home = gr.Plot(label="Zone Distribution Home")
                    zone_def_away = gr.Plot(label="Zone Distribution Away")

            # Defensive stats
            with gr.Row():
                home_def_actions = gr.Number(label="Defensive Actions", value=0)
                away_def_actions = gr.Number(label="Defensive Actions", value=0)
                home_tackle_success = gr.Number(label="Tackle Success", value=0.0)
                away_tackle_success = gr.Number(label="Tackle Success", value=0.0)

        # --------------------------------------------------------------------------
        # TAB 6: Transitions and Match Control
        # --------------------------------------------------------------------------
        with gr.Tab("Transitions and Match Control"):
            gr.Markdown("### Match Rhythm & Transitions")
            with gr.Row():
                with gr.Column(scale=1):
                    transition_home = gr.Plot(label="Transition Profile Home")
                    transition_away = gr.Plot(label="Transition Profile Away")
                with gr.Column(scale=1):
                    tempo_home = gr.Plot(label="Tempo Analysis Home")
                    tempo_away = gr.Plot(label="Tempo Analysis Away")

            # Transition stats
            with gr.Row():
                home_possessions = gr.Number(label="Possessions", value=0)
                away_possessions = gr.Number(label="Possessions", value=0)
                home_avg_duration = gr.Number(label="Avg Possession (s)", value=0.0)
                away_avg_duration = gr.Number(label="Avg Possession (s)", value=0.0)
                home_counter_presses = gr.Number(label="Counter-Presses", value=0)
                away_counter_presses = gr.Number(label="Counter-Presses", value=0)

        # --------------------------------------------------------------------------
        # TAB 7: Player Focus
        # --------------------------------------------------------------------------
        with gr.Tab("Player Focus"):
            gr.Markdown("### Select a Player to Follow Their Involvement")
            with gr.Row():
                with gr.Column(scale=1):
                    player_dropdown = gr.Dropdown(
                        choices=[e.get("player_name", "?") for e in default_events[:15] if e.get("player_name")],
                        value=None,
                        label="Select Player",
                    )
                    player_metrics = gr.Plot(label="Player Metrics Radar")
                with gr.Column(scale=1):
                    player_zone = gr.Plot(label="Zone Distribution")
                    player_channel = gr.Plot(label="Channel Distribution")

            # Player summary
            with gr.Row():
                player_involvement = gr.Number(label="Total Events", value=0)
                player_passes = gr.Number(label="Passes", value=0)
                player_shots = gr.Number(label="Shots", value=0)

        # --------------------------------------------------------------------------
        # TAB 8: Match Timeline
        # --------------------------------------------------------------------------
        with gr.Tab("Match Timeline"):
            gr.Markdown("### Interactive Match Timeline")
            with gr.Row():
                timeline_inspect = gr.Plot(value=lambda: create_match_timeline(default_events),
                                           label="Timeline", scale=2)
                # Insight timeline
                insight_timeline = gr.Plot(value=lambda: create_insight_timeline(default_events[:10] if default_events else []),
                                           label="Key Insights", scale=1)

        # --------------------------------------------------------------------------
        # TAB 9: AI Tactical Report
        # --------------------------------------------------------------------------
        with gr.Tab("AI Tactical Report"):
            gr.Markdown("### Model Classification + Deterministic Statistics")
            with gr.Row():
                with gr.Column(scale=1):
                    model_class = gr.Dropdown(
                        choices=["controlled_buildup", "direct_progression", "wide_attack",
                                 "central_progression", "high_press_turnover", "counterattack",
                                 "other_or_uncertain"],
                        value="controlled_buildup",
                        label="Model Class",
                    )
                    model_conf = gr.Slider(
                        minimum=0, maximum=1, value=0.6,
                        label="Confidence Threshold (default 0.60)",
                    )
                    run_model_btn = gr.Button("Classify Sequence", size="sm")
                with gr.Column(scale=1):
                    model_prob_fig = gr.Plot(label="Class Probabilities")
                    model_flags = gr.Textbox(label="Flags", interactive=False)

            # Model explanation
            with gr.Accordion("Model Notes", open=True):
                gr.Markdown(
                    "- Model only sees up to 14 events at a time\n"
                    "- Outputs are labelled as synthetic predictions\n"
                    "- Low confidence (< 0.60) triggers 'uncertain' label\n"
                    "- Probabilities are softmax under synthetic training distribution\n"
                    "- Not a match-winner predictor; used as one signal among statistics"
                )

            # Generated report
            report_output = gr.Textbox(lines=10, label="Tactical Report")

        # --------------------------------------------------------------------------
        # TAB 10: Viewer Preferences
        # --------------------------------------------------------------------------
        with gr.Tab("Viewer Preferences"):
            gr.Markdown("### Personalization Controls")
            with gr.Row():
                with gr.Column(scale=1):
                    save_prefs_btn = gr.Button("Save Preferences", size="sm")
                    reset_prefs_btn = gr.Button("Reset Preferences", size="sm")
                with gr.Column(scale=1):
                    export_btn = gr.Button("Export Overlays JSON", size="sm")
                    import json
                    json_out = gr.File(label="Downloaded Overlays")

            # Live preview of personalization
            with gr.Accordion("Current Profile", open=False):
                profile_summary = gr.Markdown(value="Viewer type: casual_fan")

        # --------------------------------------------------------------------------
        # Event handlers
        # --------------------------------------------------------------------------
        gen_btn.click(
            fn=get_default_match_events,
            inputs=[],
            outputs=[timeline_fig],
            show_progress=False,
        ).then(
            fn=lambda e: (
                analyze_buildup(e, "home"),
                analyze_buildup(e, "away"),
                analyze_attack(e, "home"),
                analyze_attack(e, "away"),
                analyze_defence(e, "home"),
                analyse_defence(e, "away"),
                analyze_transitions(e, "home"),
                analyze_transitions(e, "away"),
                analyze_player("", e),
                run_model_inference(e, "home"),
                run_model_inference(e, "away"),
            ),
            outputs=[
                home_third_starts, away_third_starts, home_completion, away_completion,
                home_def_actions, away_def_actions, home_possessions, away_possessions,
                home_avg_duration, away_avg_duration,
                player_metrics, model_result,
            ],
            show_progress=False,
        )

        # Update pitch figure
        gen_btn.click(
            fn=lambda e: create_pitch_figure(title="Live Match"),
            inputs=[],
            outputs=[pitch_fig],
            show_progress=False,
        )

        # Toggle play/pause
        pause_btn.click(fn=None, inputs=[], outputs=[], _js="() => { alert('Pause placeholder'); return [] }")
        resume_btn.click(fn=None, inputs=[], outputs=[], _js="() => { alert('Resume placeholder'); return [] }")

        # Player selection
        player_dropdown.input(
            fn=analyze_player,
            inputs=[player_dropdown, gr.State(default_events)],
            outputs=[player_metrics, player_zone, player_channel,
                     player_involvement, player_passes, player_shots],
        )

        # Model classification
        run_model_btn.click(
            fn=run_model_inference,
            inputs=[gr.State(default_events), gr.Dropdown(value="home", choices=["home", "aire"], visible=False)],
            outputs=[model_class, model_conf, model_prob_fig, model_flags],
        )

        # Generate narrative
        gen_narrative_btn = gr.Button("Generate Narrative", visible=False)

        # Export overlays
        export_btn.click(
            fn=export_overlays_to_json,
            inputs=[],
            outputs=[json_out],
        )

        # Reset
        reset_btn.click(
            fn=lambda: (
                get_default_match_events(),
                create_match_timeline(default_events),
                create_pitch_figure(title="Live Match"),
            ),
            outputs=[timeline_fig, pitch_fig],
        )

    # Launch
    app.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
    )


if __name__ == "__main__":
    launch_app()