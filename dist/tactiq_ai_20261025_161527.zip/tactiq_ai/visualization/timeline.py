"""TACTIQ AI - Match Timeline Visualization.

Creates interactive timeline of match events with filtering,
zoom, and event inspection.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import plotly.graph_objects as go
from plotly.subplots import make_subplots

logger = logging.getLogger(__name__)

# Event type colours
EVENT_COLOURS = {
    "pass": "#3498db",
    "carry": "#2ecc71",
    "cross": "#e67e22",
    "shot": "#e74c3c",
    "pressure": "#9b59b6",
    "tackle": "#c0392b",
    "recovery": "#1abc9c",
    "interception": "#34495e",
    "clearance": "#95a5a6",
    "ball_loss": "#f39c12",
}


def create_match_timeline(
    events: List[Dict[str, Any]],
    home_team: str = "Home",
    away_team: str = "Away",
    period_breaks: List[float] = None,
    highlight_event_ids: List[str] = None,
    show_teams: bool = True,
    width: int = 1000,
    height: int = 400,
) -> go.Figure:
    """Create an interactive match timeline with event markers.

    Args:
        events: Sorted list of match events
        home_team, away_team: Team names
        period_breaks: Timestamps where period breaks (e.g. halftime) occur
        highlight_event_ids: Event IDs to highlight
        show_teams: Color events by team
        width, height: Figure dimensions

    Returns:
        Plotly figure with scrollable timeline
    """
    sorted_events = sorted(events, key=lambda e: e.get("timestamp_seconds", 0))
    highlight_event_ids = highlight_event_ids or []

    fig = go.Figure()

    # Add half/period lines
    if period_breaks:
        for pb in period_breaks:
            fig.add_vline(x=pb, line_dash="dash", line_color="white",
                          annotation_text="HT")

    # Add each event as a marker on the timeline
    for ev in sorted_events:
        ts = ev.get("timestamp_seconds", 0)
        etype = ev.get("event_type", "unknown")
        team = ev.get("team_id", "home")
        outcome = ev.get("outcome", "")
        player = ev.get("player_name", ev.get("player_id", "?"))

        color = EVENT_COLOURS.get(etype, "#999999")
        if show_teams:
            if team == "home":
                color = "#3498db"
            elif team == "away":
                color = "#e74c3c"
            else:
                color = "#999999"

        is_shot = etype == "shot"
        marker_symbol = "flag" if is_shot else "circle"
        marker_size = 12 if is_shot else 8
        if ev.get("event_id") in highlight_event_ids:
            marker_size += 4
            marker_symbol = "star" if is_shot else "diamond"

        fig.add_trace(
            go.Scatter(
                x=[ts],
                y=[0],
                mode="markers",
                marker=dict(
                    size=marker_size,
                    color=color,
                    symbol=marker_symbol,
                    line=dict(width=1, color="white"),
                ),
                showlegend=False,
                hoverinfo="text",
                hovertext=(
                    f"<b>{etype.upper()}</b><br>"
                    f"Time: {ts:.1f}s ({ts/60:.1f} min)<br>"
                    f"Team: {team}<br>"
                    f"Player: {player}<br>"
                    f"Outcome: {outcome}"
                ),
            )
        )

    # Team labels
    if show_teams:
        fig.add_annotation(
            x=0, y=0.9, xref="paper", yref="paper",
            text=home_team,
            showarrow=False,
            font=dict(color="#3498db", size=14),
        )
        fig.add_annotation(
            x=1, y=0.9, xref="paper", yref="paper",
            text=away_team,
            showarrow=False,
            font=dict(color="#e74c3c", size=14),
        )

    fig.update_layout(
        title="Match Timeline",
        xaxis_title="Time (seconds)",
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(color="#333"),
        width=width,
        height=height,
        xaxis=dict(range=[0, max((e["timestamp_seconds"] for e in sorted_events), default=6000)]),
        yaxis=dict(visible=False, range=[-0.5, 0.5]),
    )

    return fig


def create_event_inspection_panel(
    events: List[Dict[str, Any]],
    event_ids: List[str],
    width: int = 600,
    height: int = 300,
) -> go.Figure:
    """Create a panel showing event details for a selected event.

    Shows the event's position on pitch and key statistics.
    """
    selected = [e for e in events if e.get("event_id") in event_ids]

    fig = go.Figure()

    # Pitch
    fig.add_shape(
        type="rect",
        x0=0, y0=0, x1=105, y1=68,
        line=dict(color="white", width=4),
        fillcolor="darkgreen",
    )

    # Highlight selected events
    for ev in selected:
        x = ev.get("end_x", 50)
        y = ev.get("end_y", 50)
        # Convert to 0-100 if needed (our events are already in metres)
        fig.add_trace(
            go.Scatter(
                x=[x if x <= 105 else 50],
                y=[y if y <= 68 else 34],
                mode="markers",
                marker=dict(size=15, color="yellow", symbol="star",
                            line=dict(width=2, color="white")),
                showlegend=False,
            )
        )

    fig.update_layout(
        title="Event Inspection",
        xaxis=dict(range=[0, 105], showgrid=False, showticklabels=False, zeroline=False),
        yaxis=dict(range=[0, 68], showgrid=False, showticklabels=False, zeroline=False),
        plot_bgcolor="darkgreen",
        paper_bgcolor="darkgreen",
        font=dict(color="white"),
        width=width,
        height=height,
    )

    return fig


def create_insight_timeline(
    insights: List[Dict[str, Any]],
    width: int = 1000,
    height: int = 200,
) -> go.Figure:
    """Create a timeline of insights (key moments)."""
    fig = go.Figure()

    colours = {
        "build_up": "#3498db",
        "attack": "#e74c3c",
        "defense": "#9b59b6",
        "transition": "#1abc9c",
        "player": "#e67e22",
        "model": "#f39c12",
        "moment": "#95a5a6",
    }

    for insight in insights:
        ts = insight.get("timestamp_seconds", 0)
        cat = insight.get("category", "moment")
        color = colours.get(cat, "#999999")
        headline = insight.get("headline", "")

        fig.add_trace(
            go.Scatter(
                x=[ts],
                y=[0],
                mode="markers",
                marker=dict(size=12, color=color, symbol="diamond"),
                showlegend=False,
                text=[headline],
                hovertemplate=f"<b>{headline}</b><br>Time: {ts:.1f}s",
            )
        )

    fig.update_layout(
        title="Key Insights Timeline",
        xaxis_title="Time (seconds)",
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(color="#333"),
        width=width,
        height=height,
        xaxis=dict(range=[0, max(
            (ins.get("timestamp_seconds", 0) for ins in insights),
            default=6000)]),
        yaxis=dict(visible=False, range=[-0.3, 0.3]),
    )

    return fig


__all__ = [
    "create_match_timeline",
    "create_event_inspection_panel",
    "create_insight_timeline",
]