"""TACTIQ AI - Football Pitch Visualization.

Plots interactive football pitch with event markers, pass trajectories,
possession indicators, and tactical zones using Plotly.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import plotly.graph_objects as go
import plotly.express as px

logger = logging.getLogger(__name__)

PITCH_LENGTH_M = 105.0
PITCH_WIDTH_M = 68.0

# Pitch thirds boundaries (as fraction of pitch length)
THIRD_1 = 1 / 3  # ~33.33
THIRD_2 = 2 / 3  # ~66.67

# Channel boundaries (as fraction of pitch width)
CHANNEL_EDGES = {
    "left_wide": 0.20,
    "left_halfspace": 0.38,
    "central": 0.62,
    "right_halfspace": 0.80,
    "right_wide": 1.00,
}


def create_pitch_figure(
    title: str = "Football Pitch",
    pitch_length_m: float = PITCH_LENGTH_M,
    pitch_width_m: float = PITCH_WIDTH_M,
    show_zones: bool = True,
    show_channels: bool = False,
    figsize: tuple = (10, 6.8),
) -> go.Figure:
    """Create a blank football pitch figure with optional zones/channels."""
    fig = go.Figure()

    # Scale: 1 unit = 1 metre, so width = pitch_width_m / pitch_length_m ratio
    # But we want a nice aspect ratio; use data coordinates 0-100 for x and y

    # Add pitch outline
    fig.add_trace(
        go.Scatter(
            x=[0, pitch_length_m, pitch_length_m, 0, 0],
            y=[0, 0, pitch_width_m, pitch_width_m, 0],
            mode="lines",
            line=dict(color="white", width=4),
            fillcolor="darkgreen",
            fill="toself",
            showlegend=False,
        )
    )

    # Center line
    fig.add_trace(
        go.Scatter(
            x=[pitch_length_m / 2, pitch_length_m / 2],
            y=[0, pitch_width_m],
            mode="lines",
            line=dict(color="white", width=2, dash="dash"),
            showlegend=False,
        )
    )

    # Center circle
    fig.add_trace(
        go.Scatter(
            x=[pitch_length_m / 2],
            y=[pitch_width_m / 2],
            mode="lines",
            line=dict(color="white", width=1),
            showlegend=False,
        )
    )

    # Goal areas
    # Home goal area (x=0)
    fig.add_trace(
        go.Scatter(
            x=[0, 0, 16.5, 16.5, 0],
            y=[pitch_width_m / 2 - 20.32 / 2, pitch_width_m / 2 + 20.32 / 2,
               pitch_width_m / 2 + 20.32 / 2, pitch_width_m / 2 - 20.32 / 2, 0],
            mode="lines",
            line=dict(color="white", width=2),
            fillcolor="rgba(255,255,255,0.1)",
            fill="toself",
            showlegend=False,
        )
    )

    # Away goal area (x=pitch_length_m)
    fig.add_trace(
        go.Scatter(
            x=[pitch_length_m, pitch_length_m, pitch_length_m - 16.5, pitch_length_m - 16.5, pitch_length_m],
            y=[pitch_width_m / 2 - 20.32 / 2, pitch_width_m / 2 + 20.32 / 2,
               pitch_width_m / 2 + 20.32 / 2, pitch_width_m / 2 - 20.32 / 2, pitch_width_m],
            mode="lines",
            line=dict(color="white", width=2),
            fillcolor="rgba(255,255,255,0.1)",
            fill="toself",
            showlegend=False,
        )
    )

    # Penalty areas
    for ga_x in [0, pitch_length_m]:
        fig.add_trace(
            go.Scatter(
                x=[ga_x, ga_x, ga_x + 40.32, ga_x + 40.32, ga_x],
                y=[pitch_width_m / 2 - 40.32 / 2, pitch_width_m / 2 + 40.32 / 2,
                   pitch_width_m / 2 + 40.32 / 2, pitch_width_m / 2 - 40.32 / 2, pitch_width_m / 2 - 40.32 / 2],
                mode="lines",
                line=dict(color="white", width=1.5),
                fillcolor="rgba(255,255,255,0.05)",
                fill="toself",
                showlegend=False,
            )
        )

    # Set aspect ratio
    fig.update_layout(
        title=title,
        xaxis=dict(
            range=[0, pitch_length_m],
            showgrid=False,
            showticklabels=False,
            zeroline=False,
            scaleanchor="y",
        ),
        yaxis=dict(
            range=[0, pitch_width_m],
            showgrid=False,
            showticklabels=False,
            zeroline=False,
        ),
        plot_bgcolor="darkgreen",
        paper_bgcolor="darkgreen",
        font=dict(color="white"),
        width=figsize[0] * 100,
        height=figsize[1] * 100,
        showlegend=False,
        margin=dict(l=40, r=40, t=60, b=40),
    )

    return fig


def add_pitch_players(
    fig: go.Figure,
    home_players: List[Dict[str, Any]],
    away_players: List[Dict[str, Any]],
    x_range: tuple = None,
    y_range: tuple = None,
) -> go.Figure:
    """Add player markers to pitch figure.

    Args:
        fig: The pitch figure
        home_players: List of home player dicts with x, y fields
        away_players: List of away player dicts with x, y fields
        x_range: Optional x-axis range override
        y_range: Optional y-axis range override
    """
    player_size = 12
    player_symbol = "circle"

    # Home players (blue/cyan)
    if home_players:
        home_x = [p.get("x", 50) for p in home_players]
        home_y = [p.get("y", 50) for p in home_players]
        player_colors = ["#0066cc"] * len(home_players)  # Home blue

        fig.add_trace(
            go.Scatter(
                x=home_x,
                y=home_y,
                mode="markers",
                marker=dict(
                    size=player_size,
                    color=player_colors,
                    line=dict(width=1, color="white"),
                    symbol=player_symbol,
                ),
                text=[p.get("name", "Home") for p in home_players],
                name="Home Players",
                showlegend=True,
            )
        )

    # Away players (red)
    if away_players:
        away_x = [p.get("x", 50) for p in away_players]
        away_y = [p.get("y", 50) for p in away_players]

        fig.add_trace(
            go.Scatter(
                x=away_x,
                y=away_y,
                mode="markers",
                marker=dict(
                    size=player_size,
                    color="#cc0000",
                    line=dict(width=1, color="white"),
                    symbol=player_symbol,
                ),
                text=[p.get("name", "Away") for p in away_players],
                name="Away Players",
                showlegend=True,
            )
        )

    return fig


def add_pass_trajectories(
    fig: go.Figure,
    home_passes: List[Dict[str, Any]],
    away_passes: List[Dict[str, Any]],
) -> go.Figure:
    """Add pass trajectory lines to the pitch figure."""
    # Home passes
    if home_passes:
        for p in home_passes:
            if p.get("start_x") and p.get("start_y") and p.get("end_x") and p.get("end_y"):
                color = "#0066cc" if p.get("completed", True) else "#999999"
                width = 2 if p.get("completed", True) else 1

                fig.add_trace(
                    go.Scatter(
                        x=[p["start_x"], p["end_x"]],
                        y=[p["start_y"], p["end_y"]],
                        mode="lines",
                        line=dict(color=color, width=width),
                        showlegend=False,
                        hoverinfo="skip",
                    )
                )

    # Away passes
    if away_passes:
        for p in away_passes:
            if p.get("start_x") and p.get("start_y") and p.get("end_x") and p.get("end_y"):
                color = "#cc0000" if p.get("completed", True) else "#999999"
                width = 2 if p.get("completed", True) else 1

                fig.add_trace(
                    go.Scatter(
                        x=[p["start_x"], p["end_x"]],
                        y=[p["start_y"], p["end_y"]],
                        mode="lines",
                        line=dict(color=color, width=width),
                        showlegend=False,
                        hoverinfo="skip",
                    )
                )

    return fig


def add_event_markers(
    fig: go.Figure,
    events: List[Dict[str, Any]],
    event_type: str = "pass",
    color: str = "#ffff00",
    size: int = 8,
) -> go.Figure:
    """Add event markers (start points) to the pitch figure."""
    if not events:
        return fig

    # Filter events by type
    filtered = [e for e in events if e.get("event_type") == event_type]

    if not filtered:
        return fig

    # Get start coordinates
    x_coords = [e.get("start_x", 50) for e in filtered]
    y_coords = [e.get("start_y", 50) for e in filtered]

    marker_symbols = {
        "pass": "triangle-up",
        "shot": "triangle-down",
        "carry": "square",
        "cross": "diamond",
        "pressure": "circle",
        "tackle": "pentagon",
        "recovery": "hexagon",
    }

    sym = marker_symbols.get(event_type, "circle")

    fig.add_trace(
        go.Scatter(
            x=x_coords,
            y=y_coords,
            mode="markers",
            marker=dict(
                size=size,
                color=color,
                line=dict(width=1, color="white"),
                symbol=sym,
            ),
            text=[e.get("event_id", "?") for e in filtered],
            name=f"{event_type.title()}s",
            showlegend=True,
        )
    )

    return fig


def add_zone_highlight(
    fig: go.Figure,
    zone: str = "defensive_third",
    x_range: Optional[tuple] = None,
    y_range: Optional[tuple] = None,
    opacity: float = 0.1,
) -> go.Figure:
    """Highlight a specific pitch zone (defensive/middle/attacking third)."""
    # zone is a string label

    if zone == "defensive_third":
        x0, x1 = 0, 100  # in our 0-100 model frame
    elif zone == "middle_third":
        x0, x1 = 33.33, 66.67
    elif zone == "attacking_third":
        x0, x1 = 66.67, 100
    else:
        return fig

    # Convert to pitch metres if needed
    # In data coordinates 0-100, so:
    fig.add_trace(
        go.Scatter(
            x=[x0, x1, x1, x0, x0],
            y=[0, 0, 100, 100, 0],
            mode="lines",
            line=dict(color="yellow", width=2, dash="dot"),
            fillcolor=f"rgba(255,255,0,{opacity})",
            fill="toself",
            showlegend=False,
        )
    )

    return fig


def create_shot_map(
    shots: List[Dict[str, Any]],
    home_team_attacking_right: bool = True,
) -> go.Figure:
    """Create a shot map visualization.

    Args:
        shots: List of shot dicts with x_start, y_start, zone, outcome
        home_team_attacking_right: If home team attacks toward x=100
    """
    fig = go.Figure()

    # Add pitch outline
    fig.add_trace(
        go.Scatter(
            x=[0, 100, 100, 0, 0],
            y=[0, 0, 100, 100, 0],
            mode="lines",
            line=dict(color="white", width=4),
            fillcolor="darkgreen",
            fill="toself",
            showlegend=False,
        )
    )

    # Add goal lines (vertical at x=0 and x=100)
    for gx in [0, 100]:
        fig.add_trace(
            go.Scatter(
                x=[gx, gx],
                y=[0, 100],
                mode="lines",
                line=dict(color="white", width=2),
                showlegend=False,
            )
        )

    # Shot colour coding
    for shot in shots:
        x = shot.get("x_start", 50)
        y = shot.get("y_start", 50)
        outcome = shot.get("outcome", "off_target")
        zone = shot.get("zone", "unknown")

        # Determine colour
        if outcome == "goal":
            color = "#ff0000"
        elif outcome == "on_target":
            color = "#ff6600"
        else:
            color = "#999999"

        fig.add_trace(
            go.Scatter(
                x=[x],
                y=[y],
                mode="markers",
                marker=dict(
                    size=20,
                    color=color,
                    line=dict(width=2, color="white"),
                    symbol="triangle-down",
                ),
                showlegend=False,
            )
        )

    # Add goal areas (scaled 0-100)
    fig.add_trace(
        go.Scatter(
            x=[0, 0, 16.5, 16.5, 0],
            y=[25, 75, 75, 25, 25],
            mode="lines",
            line=dict(color="white", width=1.5),
            fillcolor="rgba(255,255,255,0.05)",
            fill="toself",
            showlegend=False,
        )
    )

    fig.add_trace(
        go.Scatter(
            x=[100, 100, 83.5, 83.5, 100],
            y=[25, 75, 75, 25, 25],
            mode="lines",
            line=dict(color="white", width=1.5),
            fillcolor="rgba(255,255,255,0.05)",
            fill="toself",
            showlegend=False,
        )
    )

    fig.update_layout(
        title="Shot Map",
        xaxis=dict(range=[0, 100], showgrid=False, showticklabels=False, zeroline=False),
        yaxis=dict(range=[0, 100], showgrid=False, showticklabels=False, zeroline=False),
        plot_bgcolor="darkgreen",
        paper_bgcolor="darkgreen",
        font=dict(color="white"),
        width=800,
        height=600,
    )

    return fig


def add_possession_arc(
    fig: go.Figure,
    events: List[Dict[str, Any]],
    team_id: str,
    color: str = "#0066cc",
) -> go.Figure:
    """Add possession arc/line showing ball movement during a possession."""
    # Collect event positions in order
    x_positions = []
    y_positions = []

    for ev in events:
        if ev.get("event_type") in ("pass", "carry", "cross", "shot"):
            x_positions.append(ev.get("end_x", 50))
            y_positions.append(ev.get("end_y", 50))

    if not x_positions:
        return fig

    # Add line connecting events
    fig.add_trace(
        go.Scatter(
            x=x_positions,
            y=y_positions,
            mode="lines+markers",
            line=dict(color=color, width=3),
            marker=dict(size=6, color=color),
            showlegend=False,
            name="Ball Movement",
        )
    )

    return fig


__all__ = [
    "create_pitch_figure",
    "add_pitch_players",
    "add_pass_trajectories",
    "add_event_markers",
    "add_zone_highlight",
    "create_shot_map",
    "add_possession_arc",
]