"""TACTIQ AI - Chart Visualizations.

Plotly charts for tactical analysis: passing networks, heatmaps,
shot distributions, player metrics, possession timelines.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

import plotly.graph_objects as go
import plotly.express as px

logger = logging.getLogger(__name__)


def passing_network_chart(
    events: List[Dict[str, Any]],
    team_id: str = "home",
    min_passes: int = 1,
) -> go.Figure:
    """Create a passing network showing pass volume between pitch zones.

    Uses event start->end coordinates as edges on a pitch silhouette.
    """
    fig = go.Figure()

    # Pitch background
    fig.add_trace(
        go.Scatter(
            x=[0, 100, 100, 0, 0],
            y=[0, 0, 100, 100, 0],
            mode="lines",
            line=dict(color="white", width=4),
            fillcolor="darkgreen",
            fill="toself",
            showlegend=False,
        )
    )

    # Filter passes
    passes = [e for e in events if e.get("event_type") == "pass"]
    passes = [p for p in passes if p.get("team_id") == team_id] if passes else passes

    # Aggregate passes between start and end zones
    pass_counts = {}
    for p in passes:
        x0, y0 = p.get("start_x", 50), p.get("start_y", 50)
        x1, y1 = p.get("end_x", 50), p.get("end_y", 50)
        key = (round(x0 / 10) * 10, round(y0 / 10) * 10, round(x1 / 10) * 10, round(y1 / 10) * 10)
        pass_counts[key] = pass_counts.get(key, 0) + 1

    # Draw edges
    for (x0, y0, x1, y1), count in pass_counts.items():
        if count < min_passes:
            continue
        width = max(1, count / 2)
        color = "#00ccff" if count > 3 else "#444444"
        fig.add_trace(
            go.Scatter(
                x=[x0, x1],
                y=[y0, y1],
                mode="lines",
                line=dict(color=color, width=width),
                showlegend=False,
                hoverinfo="skip",
            )
        )

    fig.update_layout(
        title=f"Passing Network — {team_id}",
        xaxis=dict(range=[0, 100], showgrid=False, showticklabels=False, zeroline=False),
        yaxis=dict(range=[0, 100], showgrid=False, showticklabels=False, zeroline=False),
        plot_bgcolor="darkgreen",
        paper_bgcolor="darkgreen",
        font=dict(color="white"),
        width=700,
        height=500,
        showlegend=False,
    )

    return fig


def shot_map_chart(
    shots: List[Dict[str, Any]],
    title: str = "Shot Map",
) -> go.Figure:
    """Create a shot map with expected goal size encoding."""
    fig = go.Figure()

    # Pitch background
    fig.add_trace(
        go.Scatter(
            x=[0, 100, 100, 0, 0],
            y=[0, 0, 100, 100, 0],
            mode="lines",
            line=dict(color="white", width=4),
            fillcolor="darkgreen",
            fill="toself",
            showlegend=False,
        )
    )

    colours = {
        "goal": "#ff0000",
        "on_target": "#ff9900",
        "off_target": "#777777",
        "saved": "#00ff00",
    }

    for shot in shots:
        x = shot.get("x_start", 50)
        y = shot.get("y_start", 50)
        outcome = shot.get("outcome", "off_target")
        color = colours.get(outcome, "#777777")
        size = 25 if outcome == "goal" else 15

        fig.add_trace(
            go.Scatter(
                x=[x],
                y=[y],
                mode="markers",
                marker=dict(size=size, color=color, line=dict(width=2, color="white")),
                showlegend=False,
            )
        )

    fig.update_layout(
        title=title,
        xaxis=dict(range=[0, 100], showgrid=False, showticklabels=False, zeroline=False),
        yaxis=dict(range=[0, 100], showgrid=False, showticklabels=False, zeroline=False),
        plot_bgcolor="darkgreen",
        paper_bgcolor="darkgreen",
        font=dict(color="white"),
        width=700,
        height=500,
        showlegend=False,
    )

    return fig


def channel_distribution_chart(
    channel_data: Dict[str, int],
    title: str = "Channel Distribution",
) -> go.Figure:
    """Bar chart of channel usage (left_wide, left_halfspace, central, etc.)."""
    labels = list(channel_data.keys())
    values = list(channel_data.values())

    fig = go.Figure(
        data=[
            go.Bar(
                x=labels,
                y=values,
                marker_color=["#ff6b6b", "#4ecdc4", "#45b7d1", "#f7dc6f", "#bb8fce"],
            )
        ]
    )

    fig.update_layout(
        title=title,
        xaxis_title="Channel",
        yaxis_title="Events",
        plot_bgcolor="#f9f9f9",
        paper_bgcolor="#f9f9f9",
        font=dict(color="#333"),
        width=700,
        height=400,
    )

    return fig


def possession_timeline_chart(
    events: List[Dict[str, Any]],
    title: str = "Possession Timeline",
) -> go.Figure:
    """Timeline showing which team has possession over time."""
    fig = go.Figure()

    # Sort events by timestamp
    sorted_events = sorted(events, key=lambda e: e.get("timestamp_seconds", 0))

    times = []
    possession = []  # 1 = home, 0 = away

    current = None
    for ev in sorted_events:
        ts = ev.get("timestamp_seconds", 0)
        if ev.get("turnover", False) and ev.get("team_id"):
            # Turnover means possession changes
            current = "away" if ev.get("team_id") == "home" else "home"
        elif ev.get("event_type") in ("tackle", "recovery", "interception"):
            current = ev.get("team_id", "home")

        if current:
            times.append(ts)
            possession.append(1 if current == "home" else 0)

    if not times:
        fig.update_layout(title=title + " (no data)")
        return fig

    fig.add_trace(
        go.Scatter(
            x=times,
            y=possession,
            mode="lines",
            line=dict(color="#0066cc", width=3),
            name="Home Possession",
        )
    )

    fig.add_trace(
        go.Scatter(
            x=times,
            y=[0] * len(times),
            mode="lines",
            line=dict(color="rgba(0,0,0,0)"),
            showlegend=False,
            hoverinfo="skip",
        )
    )

    fig.update_layout(
        title=title,
        xaxis_title="Time (s)",
        yaxis=dict(
            range=[-0.1, 1.1],
            tickvals=[0, 1],
            ticktext=["Away Possession", "Home Possession"],
        ),
        plot_bgcolor="#f9f9f9",
        paper_bgcolor="#f9f9f9",
        font=dict(color="#333"),
        width=800,
        height=300,
        showlegend=False,
    )

    return fig


def defensive_actions_chart(
    defence_data: Dict[str, Any],
    title: str = "Defensive Actions by Zone",
) -> go.Figure:
    """Bar chart of defensive actions distributed across pitch zones."""
    zone_dist = defence_data.get("zone_distribution", {})

    if not zone_dist:
        fig = go.Figure()
        fig.update_layout(title=title + " (no data)", width=600, height=400)
        return fig

    labels = list(zone_dist.keys())
    values = list(zone_dist.values())

    fig = go.Figure(
        data=[go.Bar(x=labels, y=values, marker_color="#e74c3c")]
    )

    fig.update_layout(
        title=title,
        xaxis_title="Zone",
        yaxis_title="Actions",
        plot_bgcolor="#f9f9f9",
        paper_bgcolor="#f9f9f9",
        font=dict(color="#333"),
        width=700,
        height=400,
    )

    return fig


def player_metrics_chart(
    players_data: List[Dict[str, Any]],
    metric: str = "total_passes",
    title: str = None,
) -> go.Figure:
    """Bar chart comparing players on a selected metric."""
    if not players_data:
        fig = go.Figure()
        fig.update_layout(title=title or "Player Metrics", width=700, height=400)
        return fig

    names = [p.get("player_name", p.get("player_id", "?")) for p in players_data]
    values = []
    for p in players_data:
        data = p.get("data", p)
        if isinstance(data, dict):
            val = data.get(metric, 0)
        else:
            val = 0
        values.append(val)

    title = title or f"Player Comparison — {metric.replace('_', ' ').title()}"

    fig = go.Figure(
        data=[go.Bar(x=names, y=values, marker_color="#2ecc71")]
    )

    fig.update_layout(
        title=title,
        xaxis_title="Player",
        yaxis_title=metric.replace("_", " ").title(),
        plot_bgcolor="#f9f9f9",
        paper_bgcolor="#f9f9f9",
        font=dict(color="#333"),
        width=800,
        height=400,
    )

    return fig


def model_prediction_chart(
    class_probabilities: Dict[str, float],
    predicted_class: str,
    title: str = "Model Prediction",
) -> go.Figure:
    """Bar chart showing class probabilities from the Keras model."""
    labels = list(class_probabilities.keys())
    values = list(class_probabilities.values())

    colours = ["#ff6b6b" if l == predicted_class else "#4ecdc4" for l in labels]

    fig = go.Figure(
        data=[go.Bar(x=labels, y=values, marker_color=colours)]
    )

    fig.update_layout(
        title=title,
        xaxis_title="Tactical Class",
        yaxis_title="Probability",
        yaxis=dict(range=[0, 1]),
        plot_bgcolor="#f9f9f9",
        paper_bgcolor="#f9f9f9",
        font=dict(color="#333"),
        width=700,
        height=400,
    )

    return fig


__all__ = [
    "passing_network_chart",
    "shot_map_chart",
    "channel_distribution_chart",
    "possession_timeline_chart",
    "defensive_actions_chart",
    "player_metrics_chart",
    "model_prediction_chart",
]